### Resampling Program Readme

#### Description:
This program resamples a PGM image using nearest neighbor interpolation.

#### Instructions:
1. Compile the program using the provided source code (ip_project1_resampling.c).
2. Run the compiled program with the following command line arguments:

./ip_project1_resampling <input_ppm> <downsampled_output_ppm> <upsampled_output_ppm>

- `<input_ppm>`: Path to the input PGM file.
- `<downsampled_output_ppm>`: Path to save the downscaled output PGM file.
- `<upsampled_output_ppm>`: Path to save the upscaled output PGM file.

#### Output Images:
- **Downscaled Image (t = 0.5):**
- Filename: downsampled_output.pgm
- Scaling Factor (t): 0.5
- **Upscaled Image (t = 2.0):**
- Filename: upsampled_output.pgm
- Scaling Factor (t): 2.0
	 