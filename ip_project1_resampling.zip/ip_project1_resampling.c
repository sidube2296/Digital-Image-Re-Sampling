#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <malloc.h>

#define maximum(x, y) ((x>y) ? (x):(y))
#define minimum(x, y) ((x<y) ? (x):(y))

int xdim;  // Width of the input image
int ydim;  // Height of the input image
unsigned char* image;  // Pointer to store the image data

void ReadPGM(FILE*);  // Function prototype for reading PGM image
void WritePGM(FILE*, char*);  // Function prototype for writing PGM image
void resample_image(double scale_factor, char* output_filename);  // Function prototype for resampling image

// Function to resample the image
void resample_image(double scale_factor, char* output_filename) {
    int new_height = (int)(ydim * scale_factor);  // Calculate new height after resampling
    int new_width = (int)(xdim * scale_factor);   // Calculate new width after resampling

    // Allocate memory for the output image
    unsigned char* output_image = (unsigned char*)malloc(new_height * new_width * sizeof(unsigned char));

    // Loop through each pixel of the output image
    for (int y_out = 0; y_out < new_height; y_out++) {
        for (int x_out = 0; x_out < new_width; x_out++) {
            // Calculate corresponding coordinates in the input image
            double x_in = x_out / scale_factor;
            double y_in = y_out / scale_factor;

            // Calculate indices of the four nearest pixels in the input image
            int x1 = (int)x_in;
            int y1 = (int)y_in;
            int x2 = minimum(x1 + 1, xdim - 1);
            int y2 = minimum(y1 + 1, ydim - 1);

            // Perform bilinear interpolation to calculate the output pixel value
            double top_left = image[y1 * xdim + x1] * (x2 - x_in) * (y2 - y_in);
            double top_right = image[y1 * xdim + x2] * (x_in - x1) * (y2 - y_in);
            double bottom_left = image[y2 * xdim + x1] * (x2 - x_in) * (y_in - y1);
            double bottom_right = image[y2 * xdim + x2] * (x_in - x1) * (y_in - y1);
            double output_pixel = top_left + top_right + bottom_left + bottom_right;

            // Store the calculated pixel value in the output image
            output_image[y_out * new_width + x_out] = (unsigned char)output_pixel;
        }
    }

    // Write the output image to a file
    FILE* fp;
    if (fopen_s(&fp, output_filename, "wb") != 0) {  // Open file for writing
        printf("Write error...\n");
        exit(0);
    }
    WritePGM(fp, output_image, new_width, new_height);  // Write PGM image
    fclose(fp);  // Close file

    // Free memory allocated for the output image
    free(output_image);
}

// Main function
int main(int argc, char** argv) {
    FILE* fp;

    // Check if correct number of command line arguments are provided
    if (argc != 4) {
        printf("Usage: MyProgram <input_ppm> <downsampled_output_ppm> <upsampled_output_ppm>\n");
        printf("       <input_ppm>: PGM file \n");
        printf("       <downsampled_output_ppm>: PGM file for downscaled image\n");
        printf("       <upsampled_output_ppm>: PGM file for upscaled image\n");
        exit(0);
    }

    printf("Begin reading PGM.... \n");

    // Open the input PGM file
    if (fopen_s(&fp, argv[1], "rb") != 0) {
        printf("Read error...\n");
        exit(0);
    }

    // Read the input PGM image
    ReadPGM(fp);

    // Define scaling factors for downsampling and upsampling
    double downscale_factor = 0.5;
    double upscale_factor = 2.0;

    // Resample the image for downsampling and upsampling
    resample_image(downscale_factor, argv[2]);
    resample_image(upscale_factor, argv[3]);

    // Close the input file
    fclose(fp);

    return 0;
}

// Function to read PGM image
void ReadPGM(FILE* fp) {
    int c;
    char buf[1024];

    // Skip comments in the PGM file
    while ((c = fgetc(fp)) == '#')
        fgets(buf, 1024, fp);
    ungetc(c, fp);

    // Read the image format (P2 or P5)
    if (fscanf(fp, "P%d\n", &c) != 1) {
        printf("Read error ....");
        exit(0);
    }

    // Check if the image format is valid
    if (c != 5 && c != 2) {
        printf("Read error ....");
        exit(0);
    }

    // Read width, height, and maximum pixel value
    if (c == 5) {  // Binary PGM
        while ((c = fgetc(fp)) == '#')
            fgets(buf, 1024, fp);
        ungetc(c, fp);
        if (fscanf(fp, "%d%d", &xdim, &ydim) != 2) {
            printf("Failed to read width/height/max\n");
            exit(0);
        }
        printf("Width=%d, Height=%d\n", xdim, ydim);

        // Allocate memory for the image data
        image = (unsigned char*)malloc(sizeof(unsigned char) * xdim * ydim);
        getc(fp);

        // Read pixel values
        for (int j = 0; j < ydim; j++) {
            fread(&image[j * xdim], 1, xdim, fp);
        }
    }
    else if (c == 2) {  // ASCII PGM
        while ((c = fgetc(fp)) == '#')
            fgets(buf, 1024, fp);
        ungetc(c, fp);
        if (fscanf(fp, "%d%d", &xdim, &ydim) != 2) {
            printf("Failed to read width/height/max\n");
            exit(0);
        }
        printf("Width=%d, Height=%d\n", xdim, ydim);

        // Allocate memory for the image data
        image = (unsigned char*)malloc(sizeof(unsigned char) * xdim * ydim);
        getc(fp);

        // Read pixel values
        for (int j = 0; j < ydim; j++) {
            for (int i = 0; i < xdim; i++) {
                int val;
                fscanf(fp, "%d", &val);
                image[j * xdim + i] = (unsigned char)val;
            }
        }
    }

    // Close the file
    fclose(fp);
}

// Function to write PGM image
void WritePGM(FILE* fp, unsigned char* output_image, int width, int height) {
    // Write PGM header
    fprintf(fp, "P5\n%d %d\n255\n", width, height);

    // Write pixel data
    fwrite(output_image, sizeof(unsigned char), width * height, fp);
}